<?php

if (isset($_GET["id_Material"]) && is_numeric($_GET["id_Material"])) {

    include("../connection/connection.php");
    $con = connection();

    $id_Material = mysqli_real_escape_string($con, $_GET["id_Material"]);

    $sql = "DELETE FROM tblMaterial  WHERE id_Material = $id_Material";

    $query = mysqli_query($con, $sql);

    if ($query) {
        echo("se eliminó material");
        exit();
    } else {
        echo "Error al eliminar el empleado: " . mysqli_error($con);
    }

} else {
    echo "Id  no proporcionada o es inválida.";
}
?>
