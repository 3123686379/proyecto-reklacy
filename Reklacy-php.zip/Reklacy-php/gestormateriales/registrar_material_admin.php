<?php
// Include the database connection file
include("../connection/connection.php");
$con = connection();

// Fetch data from the tblMaterial table
$sqlMateriales = "SELECT * FROM tblMaterial";
$queryMateriales = mysqli_query($con, $sqlMateriales);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilomar.css"> <!-- Ensure this file is present and contains necessary styles -->
    <title>Materiales</title>
</head>
<body>
    <center>
    <div class="materials-form">
        <h2>Registrar Material</h2>
        <!-- Add proper validation and sanitation for user inputs -->
        <form action="insert_material.php" method="POST">
            <input type="text" name="id_Material" placeholder="Id Usuario">
            <input type="text" name="nombre_Material" placeholder="Nombre del Material">
            <input type="text" name="tipo_Material" placeholder="Tipo de Material">
            <input type="text" name="Tarifa" placeholder="Tarifa">
            <input type="text" name="Peso" placeholder="Peso">
            <input type="submit" value="agregar">
        </form>
    </div>
            
        </form>
    </div> 

    
    <div class="materials-table">
        <h2>Materiales Registrados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Usuario</th>
                    <th>Nombre del Material</th>
                    <th>Tipo de Material</th>
                    <th>Tarifa</th>
                    <th>Peso</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Display material data in the table
                while ($row = mysqli_fetch_array($queryMateriales)) :
                ?>
                    <tr>
                        <td><?= isset($row['id_Material']) ? $row['id_Material'] : 'N/A'; ?></td>
                        <td><?= isset($row['nombre_Material']) ? $row['nombre_Material'] : 'N/A'; ?></td>
                        <td><?= isset($row['tipo_Material']) ? $row['tipo_Material'] : 'N/A'; ?></td>
                        <td><?= isset($row['Tarifa']) ? $row['Tarifa'] : 'N/A'; ?></td>
                        <td><?= isset($row['Peso']) ? $row['Peso'] : 'N/A'; ?></td>
                        <!-- Include the material ID in the URL for editing and deleting -->
                        <td><a href="update_material.php?id_Material=<?= isset($row['id_Material']) ? $row['id_Material'] : ''; ?>" class="materials-table--edit">Editar</a></td>
                        <td><a href="delete_material.php?id_Material=<?= isset($row['id_Material']) ? $row['id_Material'] : ''; ?>" class="materials-table--delete">Eliminar</a></td>
                    </tr>
                <?php
                endwhile;
                ?>
            </tbody>
        </table>
        
    </div><button type="button"> <a href="../principal/principal.html"> volver </a> </button>
    </center>
</body>
</html> 