<?php
include("../connection/connection.php");
$con = connection();


$id_usuario = $_POST['id_usuario'];
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$contraseña = $_POST['contraseña'];


$checkUsuario = mysqli_query($con, "SELECT * FROM tblUsuario WHERE id_Usuario = '$id_usuario'");
if (mysqli_num_rows($checkUsuario) == 0) {

    $sql = "INSERT INTO tblUsuario (id_Usuario, Nombre, Correo, Telefono, Direccion, Contraseña) VALUES ('$id_usuario', '$nombre', '$correo', '$telefono', '$direccion', '$contraseña')";
    $query = mysqli_query($con, $sql);

    if ($query) {
        echo("Usuario Registrado");
    } else {
        echo "Error al insertar usuario: " . mysqli_error($con);
    }
} else {
    echo "Error: El usuario con ID '$id_usuario' ya existe.";
}
?>
